import numpy as np

class KMenoids_class:

    def __init__(self, n_clusters, max_iters=100):
        self.n_clusters = n_clusters
        self.max_iters = max_iters

    def fit(self, X):
        self.X = X
        self.centroids = X[np.random.choice(range(len(X)), self.n_clusters, replace=False)]

        for _ in range(self.max_iters):
            # Assign each data point to the nearest centroid
            self.labels = np.argmin(np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2), axis=1)

            # Update centroids as the mean of the data points in each cluster
            new_centroids = np.array([X[self.labels == j][np.argmin(np.sum(np.abs(X[self.labels == j] - np.median(X[self.labels == j], axis=0)), axis=1))] for j in range(self.n_clusters)])

            # Check for convergence
            if np.all(self.centroids == new_centroids):
                break

            self.centroids = new_centroids

    def transform(self, X):
        # Assign data points to the nearest centroids
        return np.argmin(np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2), axis=1)

    def fit_transform(self, X):
        self.fit(X)
        return self.labels

    def predict(self, X):
        return self.transform(X)

    def fit_predict(self, X):
        self.fit(X)
        return self.labels